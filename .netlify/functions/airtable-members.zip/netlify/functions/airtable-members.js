var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/airtable-members.mjs
var airtable_members_exports = {};
__export(airtable_members_exports, {
  findMemberByEmail: () => findMemberByEmail,
  handler: () => handler,
  upsertMember: () => upsertMember
});
module.exports = __toCommonJS(airtable_members_exports);
var AIRTABLE_API_URL = "https://api.airtable.com/v0";
var DEFAULT_BASE_ID = "appQxIhwr00DmKBx5";
var DEFAULT_MEMBERS_TABLE = "Members";
var json = (statusCode, body) => ({
  statusCode,
  headers: { "content-type": "application/json" },
  body: JSON.stringify(body)
});
var getConfig = () => ({
  token: process.env.AIRTABLE_TOKEN || process.env.AIRTABLE_API_KEY,
  baseId: process.env.AIRTABLE_BASE_ID || DEFAULT_BASE_ID,
  tableId: process.env.AIRTABLE_MEMBERS_TABLE_ID || DEFAULT_MEMBERS_TABLE
});
var escapeFormulaString = (value) => String(value).replace(/\\/g, "\\\\").replace(/"/g, '\\"');
var normalizeBoolean = (value) => value === true || String(value).toLowerCase() === "true";
var mapMember = (record) => {
  const fields = record?.fields || {};
  return {
    recordId: record?.id || "",
    email: fields.Email || "",
    paid: normalizeBoolean(fields.Paid),
    membershipType: fields["Membership Type"] || "",
    profileComplete: normalizeBoolean(fields["Profile Complete"]),
    name: fields.Name || "",
    pronouns: fields.Pronouns || "",
    birthday: fields.Birthday || "",
    instagram: fields.Instagram || "",
    neighborhood: fields.Neighborhood || "",
    heard: fields["Heard About Us"] || "",
    interests: fields.Interests || "",
    experience: fields["Experience Level"] || "",
    bio: fields.Bio || "",
    stripeCustomerId: fields["Stripe Customer ID"] || "",
    stripeSubscriptionId: fields["Stripe Subscription ID"] || ""
  };
};
var toFields = (member) => {
  const fields = {};
  const setString = (name, value) => {
    if (value !== void 0 && value !== null) fields[name] = String(value);
  };
  setString("Email", member.email);
  if (member.paid !== void 0) fields.Paid = Boolean(member.paid);
  setString("Membership Type", member.membershipType);
  if (member.profileComplete !== void 0) {
    fields["Profile Complete"] = Boolean(member.profileComplete);
  }
  setString("Name", member.name);
  setString("Pronouns", member.pronouns);
  setString("Birthday", member.birthday);
  setString("Instagram", member.instagram);
  setString("Neighborhood", member.neighborhood);
  setString("Heard About Us", member.heard);
  setString("Interests", member.interests);
  setString("Experience Level", member.experience);
  setString("Bio", member.bio);
  setString("Stripe Customer ID", member.stripeCustomerId);
  setString("Stripe Subscription ID", member.stripeSubscriptionId);
  return fields;
};
var findMemberByEmail = async (email) => {
  const { token, baseId, tableId } = getConfig();
  if (!token) throw new Error("Missing AIRTABLE_TOKEN environment variable");
  const normalizedEmail = String(email || "").trim().toLowerCase();
  if (!normalizedEmail) return null;
  const params = new URLSearchParams({
    pageSize: "1",
    filterByFormula: `LOWER({Email})="${escapeFormulaString(normalizedEmail)}"`
  });
  const response = await fetch(`${AIRTABLE_API_URL}/${baseId}/${encodeURIComponent(tableId)}?${params}`, {
    headers: { authorization: `Bearer ${token}` }
  });
  if (!response.ok) throw new Error(await response.text());
  const payload = await response.json();
  const record = payload.records?.[0];
  return record ? mapMember(record) : null;
};
var upsertMember = async (member) => {
  const { token, baseId, tableId } = getConfig();
  if (!token) throw new Error("Missing AIRTABLE_TOKEN environment variable");
  const email = String(member.email || "").trim().toLowerCase();
  if (!email) throw new Error("Missing member email");
  const existing = member.recordId ? { recordId: member.recordId } : await findMemberByEmail(email);
  const fields = toFields({ ...member, email });
  const urlBase = `${AIRTABLE_API_URL}/${baseId}/${encodeURIComponent(tableId)}`;
  const response = await fetch(existing?.recordId ? `${urlBase}/${existing.recordId}` : urlBase, {
    method: existing?.recordId ? "PATCH" : "POST",
    headers: {
      authorization: `Bearer ${token}`,
      "content-type": "application/json"
    },
    body: JSON.stringify({ fields })
  });
  if (!response.ok) throw new Error(await response.text());
  return mapMember(await response.json());
};
var handler = async (event) => {
  try {
    if (event.httpMethod === "GET") {
      const member = await findMemberByEmail(event.queryStringParameters?.email || "");
      return json(200, { member });
    }
    if (event.httpMethod === "POST" || event.httpMethod === "PUT") {
      const payload = event.body ? JSON.parse(event.body) : {};
      const member = await upsertMember(payload.member || payload);
      return json(200, { member });
    }
    return json(405, { error: "Method not allowed" });
  } catch (error) {
    return json(500, {
      error: "Airtable member request failed",
      detail: error instanceof Error ? error.message : String(error)
    });
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  findMemberByEmail,
  handler,
  upsertMember
});
