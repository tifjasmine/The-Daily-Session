var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/visitors-locked.mjs
var visitors_locked_exports = {};
__export(visitors_locked_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(visitors_locked_exports);
var AIRTABLE_API_URL = "https://api.airtable.com/v0";
var DEFAULT_BASE_ID = "appQxIhwr00DmKBx5";
var DEFAULT_TABLE_NAME = "Visitors While Locked";
var json = (statusCode, body) => ({
  statusCode,
  headers: { "content-type": "application/json" },
  body: JSON.stringify(body)
});
var clean = (value) => String(value || "").trim();
var handler = async (event) => {
  if (event.httpMethod !== "POST") return json(405, { error: "Method not allowed" });
  const token = process.env.AIRTABLE_TOKEN || process.env.AIRTABLE_API_KEY;
  const baseId = process.env.AIRTABLE_BASE_ID || DEFAULT_BASE_ID;
  const table = process.env.AIRTABLE_LOCKED_VISITORS_TABLE_ID || process.env.AIRTABLE_VISITORS_WHILE_LOCKED_TABLE_ID || DEFAULT_TABLE_NAME;
  if (!token) return json(500, { error: "Missing AIRTABLE_TOKEN environment variable" });
  const payload = JSON.parse(event.body || "{}");
  const name = clean(payload.name) || "Site visitor";
  const email = clean(payload.email).toLowerCase();
  if (!email || !email.includes("@")) return json(400, { error: "Enter a valid email address." });
  try {
    const response = await fetch(`${AIRTABLE_API_URL}/${baseId}/${encodeURIComponent(table)}`, {
      method: "POST",
      headers: {
        authorization: `Bearer ${token}`,
        "content-type": "application/json"
      },
      body: JSON.stringify({ records: [{ fields: { Name: name, Email: email } }] })
    });
    const text = await response.text();
    const result = text ? JSON.parse(text) : {};
    if (!response.ok) {
      return json(response.status, {
        error: "Airtable visitor request failed",
        detail: result?.error?.message || result?.error || text
      });
    }
    return json(200, { ok: true, id: result.records?.[0]?.id || "" });
  } catch (error) {
    return json(500, {
      error: "Unable to save visitor",
      detail: error instanceof Error ? error.message : String(error)
    });
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
